from flask import render_template,redirect,session,request, flash
from flask_app import app
from flask_app.models.user_model import User
from flask_app.models.meet_model import Meet


@app.route('/user_account/<int:id>')
def show_account(id):
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'id': session['user_id']
    }
    return render_template('show_account.html', user = User.get_by_id(data))


@app.route("/edit_meet/<int:id>")
def show_edit_meet(id):
    if 'user_id' not in session:
        return redirect('/')
    return render_template("edit_meet.html", meet = Meet.get_one_meet({'id':id}))

@app.route("/edit_meet/<int:id>", methods = ['post'])
def edit_meet(id):
    if not Meet.validate_meet(request.form):
        return redirect(f'/edit_meet/{id}' )
    data = {
        "name": request.form["name"],
        "location": request.form["location"],
        "date": request.form["date"],
        "information": request.form["information"],
        "id": id
    }
    Meet.edit_meet(data)
    return redirect("/dashboard")

@app.route('/new_meet')
def meet():
    if 'user_id' not in session:
        return redirect('/')
    return render_template('new_meet.html')

@app.route('/new_meet', methods = ['post'])
def create_meet():
    if not Meet.validate_meet(request.form):
        return redirect('/new_meet' )
    Meet.save(request.form)
    return redirect('/dashboard')

@app.route("/delete_meet/<int:id>")
def delete(id):
    Meet.delete(id)
    return redirect("/dashboard")

@app.route('/meets/<int:id>')
def display_meet(id):
    return render_template('display_meet.html', user_meet = User.get_user_with_meet({'id':id}))